<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Fantasy Premier League</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://unpkg.com/@picocss/pico@2/css/pico.min.css" rel="stylesheet">
  <style>
    body { max-width: 1100px; margin: 2rem auto; }
    .grid { display: grid; gap: 1rem; }
    .grid-3 { grid-template-columns: repeat(3, 1fr); }
    .badge { font-size: 12px; padding: 2px 6px; border: 1px solid #ccc; border-radius: 6px; }
    .price { font-weight: 700; }
    nav a { margin-right: .75rem; }
  </style>
</head>
<body>
  <nav>
    <a href="{{ route('players.index') }}">Players</a>
    <a href="{{ route('team.show') }}">My Team</a>
    <a href="{{ route('team.select') }}">Pick Team</a>
    <a href="{{ route('transfers.index') }}">Transfers</a>
  </nav>
  @if ($errors->any())
    <article style="border-left:4px solid #d33; padding-left:12px;">
      <strong>Errors</strong>
      <ul>
        @foreach ($errors->all() as $e)
          <li>{{ $e }}</li>
        @endforeach
      </ul>
    </article>
  @endif
  @if (session('ok'))
    <article style="border-left:4px solid #3a5; padding-left:12px;">{{ session('ok') }}</article>
  @endif
  <main>
    @yield('content')
  </main>
</body>
</html>