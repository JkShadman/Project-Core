@extends('layouts.app')

@section('content')
<h2>My Team ({{ $gw->name }})</h2>
<p><strong>Remaining budget:</strong> £{{ number_format($remaining,1) }}m</p>

<div class="grid grid-3">
@foreach ($players as $pl)
  <article>
    <h4>{{ $pl->name }} <small class="badge">{{ $pl->position }}</small></h4>
    <p>{{ $pl->club }}</p>
    <p class="price">£{{ number_format($pl->price,1) }}m</p>
  </article>
@endforeach
</div>

@if (empty($byPos))
<p>No squad yet. <a href="{{ route('team.select') }}">Pick your team</a>.</p>
@else
<hr>
<p><strong>Composition</strong> — 
  GK: {{ $byPos['GK'] ?? 0 }},
  DEF: {{ $byPos['DEF'] ?? 0 }},
  MID: {{ $byPos['MID'] ?? 0 }},
  FWD: {{ $byPos['FWD'] ?? 0 }}
</p>
@endif
@endsection