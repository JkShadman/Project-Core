@extends('layouts.app')

@section('content')
<h2>Pick Your Squad ({{ $gw->name }})</h2>
<p>Rules: 15 players exactly — GK×2, DEF×5, MID×5, FWD×3. Total budget ≤ £100.0m</p>

<form method="post" action="{{ route('team.save') }}">
  @csrf
  <div class="grid grid-3">
    @foreach ($players as $pl)
      <label style="border:1px solid #ddd; padding:10px; border-radius:8px;">
        <input type="checkbox" name="player_ids[]" value="{{ $pl->id }}"
               @checked(in_array($pl->id, $existing))>
        <strong>{{ $pl->name }}</strong>
        <span class="badge">{{ $pl->position }}</span><br>
        <small>{{ $pl->club }}</small><br>
        <span class="price">£{{ number_format($pl->price,1) }}m</span>
      </label>
    @endforeach
  </div>
  <button type="submit">Save Squad</button>
</form>
@endsection