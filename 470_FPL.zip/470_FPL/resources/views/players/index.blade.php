@extends('layouts.app')

@section('content')
<h2>Players</h2>

<form method="get" class="grid" style="grid-template-columns: 2fr 1fr 1fr 1fr;">
  <input type="text" name="q" value="{{ request('q') }}" placeholder="Search by name/club/position">
  <select name="position">
    <option value="">All positions</option>
    @foreach (['GK','DEF','MID','FWD'] as $p)
      <option value="{{ $p }}" @selected(request('position')===$p)>{{ $p }}</option>
    @endforeach
  </select>
  <select name="sort">
    <option value="price" @selected(request('sort')==='price')>Sort by price</option>
    <option value="name" @selected(request('sort')==='name')>Sort by name</option>
    <option value="club" @selected(request('sort')==='club')>Sort by club</option>
  </select>
  <select name="dir">
    <option value="desc" @selected(request('dir')==='desc')>Desc</option>
    <option value="asc" @selected(request('dir')==='asc')>Asc</option>
  </select>
  <button type="submit">Apply</button>
</form>

<div class="grid grid-3" style="margin-top:1rem;">
@foreach ($players as $pl)
  <article>
    <header>
      <h3>{{ $pl->name }}</h3>
      <small class="badge">{{ $pl->position }}</small>
    </header>
    <p><strong>Club:</strong> {{ $pl->club }}</p>
    <p class="price">£{{ number_format($pl->price,1) }}m</p>
  </article>
@endforeach
</div>

{{ $players->links() }}
@endsection