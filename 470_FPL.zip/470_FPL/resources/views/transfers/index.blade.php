@extends('layouts.app')

@section('content')
<h2>Transfers ({{ $gw->name }})</h2>

@if ($locked)
  <article>Transfers are locked for {{ $gw->name }} (deadline passed).</article>
@endif

<p>Free transfers this GW: 1. Extra transfers cost 4 points each.</p>
<p>Transfers made this GW: <strong>{{ $made }}</strong></p>

<h3>Your Squad</h3>
<div class="grid grid-3">
@foreach ($current as $pl)
  <article>
    <h4>{{ $pl->name }} <small class="badge">{{ $pl->position }}</small></h4>
    <p>{{ $pl->club }}</p>
    <p class="price">£{{ number_format($pl->price,1) }}m</p>
    <form method="post" action="{{ route('transfers.swap') }}">
      @csrf
      <input type="hidden" name="out_player_id" value="{{ $pl->id }}">
      <select name="in_player_id" @disabled($locked)>
        @foreach ($market->where('position', $pl->position) as $m)
          @if (!in_array($m->id, $ownedIds))
            <option value="{{ $m->id }}">{{ $m->name }} ({{ $m->club }}) - £{{ number_format($m->price,1) }}m</option>
          @endif
        @endforeach
      </select>
      <button type="submit" @disabled($locked)>Swap</button>
    </form>
  </article>
@endforeach
</div>
@endsection