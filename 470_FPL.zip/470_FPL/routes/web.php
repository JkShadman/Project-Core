<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PlayerController;
use App\Http\Controllers\TeamController;
use App\Http\Controllers\TransferController;

Route::get('/', fn() => redirect()->route('players.index'));

Route::get('/players', [PlayerController::class, 'index'])->name('players.index');

Route::prefix('/team')->group(function () {
    Route::get('/', [TeamController::class, 'show'])->name('team.show');
    Route::get('/select', [TeamController::class, 'selectForm'])->name('team.select');
    Route::post('/save', [TeamController::class, 'saveSelection'])->name('team.save');
});

Route::prefix('/transfers')->group(function () {
    Route::get('/', [TransferController::class, 'index'])->name('transfers.index');
    Route::post('/swap', [TransferController::class, 'swap'])->name('transfers.swap');
});