<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Http;
use App\Models\Player;

class ImportFplPlayersCommandTest extends TestCase
{
    use RefreshDatabase;

    public function test_importer_creates_players_from_bootstrap_static(): void
    {
        Http::fake([
            'https://fantasy.premierleague.com/api/bootstrap-static/*' => Http::response([
                'element_types' => [
                    ['id'=>1,'singular_name_short'=>'GKP'],
                    ['id'=>2,'singular_name_short'=>'DEF'],
                    ['id'=>3,'singular_name_short'=>'MID'],
                    ['id'=>4,'singular_name_short'=>'FWD'],
                ],
                'teams' => [
                    ['id'=>1,'name'=>'Arsenal'],
                    ['id'=>2,'name'=>'Liverpool'],
                ],
                'elements' => [
                    ['first_name'=>'Aaron','second_name'=>'Ramsdale','element_type'=>1,'team'=>1,'now_cost'=>50],
                    ['first_name'=>'Virgil','second_name'=>'van Dijk','element_type'=>2,'team'=>2,'now_cost'=>65],
                ],
            ], 200),
        ]);

        $this->artisan('fpl:import-latest')
             ->expectsOutputToContain('Imported players: 2')
             ->assertExitCode(0);

        $this->assertDatabaseHas('players', ['name'=>'Aaron Ramsdale', 'position'=>'GK', 'club'=>'Arsenal', 'price'=>5.0]);
        $this->assertDatabaseHas('players', ['name'=>'Virgil van Dijk', 'position'=>'DEF', 'club'=>'Liverpool', 'price'=>6.5]);

        $this->assertEquals(2, Player::count());
    }
}