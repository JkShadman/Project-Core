<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Player;

class PlayersIndexTest extends TestCase
{
    use RefreshDatabase;

    public function test_players_index_lists_players(): void
    {
        Player::factory()->count(5)->create();
        $this->get('/players')->assertStatus(200)->assertSee('Players');
    }

    public function test_players_filter_by_position_and_search(): void
    {
        Player::factory()->create(['name'=>'Erling Haaland','position'=>'FWD','club'=>'Manchester City','price'=>14.0]);
        Player::factory()->create(['name'=>'Alisson Becker','position'=>'GK','club'=>'Liverpool','price'=>6.0]);

        $this->get('/players?position=FWD&q=Haaland')
            ->assertStatus(200)
            ->assertSee('Erling Haaland')
            ->assertDontSee('Alisson Becker');
    }
}