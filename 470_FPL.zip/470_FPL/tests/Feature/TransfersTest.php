<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\{Player, Team, TeamPlayer, Gameweek, Transfer};

class TransfersTest extends TestCase
{
    use RefreshDatabase;

    private function setupSquad(): array
    {
        $gw = Gameweek::create(['name'=>'GW1','number'=>1,'deadline_at'=>now()->addDay()]);
        $team = Team::create(['user_id'=>1,'budget'=>100.0]);

        // Minimal 15-man squad
        $squad = collect()
            ->merge(Player::factory()->count(2)->create(['position'=>'GK','price'=>4.5]))
            ->merge(Player::factory()->count(5)->create(['position'=>'DEF','price'=>5.0]))
            ->merge(Player::factory()->count(5)->create(['position'=>'MID','price'=>6.0]))
            ->merge(Player::factory()->count(3)->create(['position'=>'FWD','price'=>6.0]));

        foreach ($squad as $p) {
            TeamPlayer::create([
                'team_id'=>$team->id,'player_id'=>$p->id,'gameweek_id'=>$gw->id,'is_squad'=>true
            ]);
        }

        return [$gw, $team, $squad];
    }

    public function test_free_transfer_then_penalty_for_extra(): void
    {
        [$gw, $team, $squad] = $this->setupSquad();

        $out = $squad->firstWhere('position','DEF');
        $in  = Player::factory()->create(['position'=>'DEF','price'=>5.0]);

        // First transfer = free
        $this->post('/transfers/swap', ['out_player_id'=>$out->id,'in_player_id'=>$in->id])
             ->assertSessionHas('ok');

        $this->assertEquals(1, Transfer::count());
        $team->refresh();
        $this->assertEquals(0, $team->transfer_points);

        // Second transfer in same GW costs -4
        $out2 = $squad->firstWhere('position','MID');
        $in2  = Player::factory()->create(['position'=>'MID','price'=>6.0]);

        $this->post('/transfers/swap', ['out_player_id'=>$out2->id,'in_player_id'=>$in2->id])
             ->assertSessionHas('ok');

        $team->refresh();
        $this->assertEquals(-4, $team->transfer_points);
    }

    public function test_cannot_swap_if_deadline_passed(): void
    {
        [$gw, $team, $squad] = $this->setupSquad();
        $gw->update(['deadline_at'=>now()->subMinute()]);

        $out = $squad->firstWhere('position','DEF');
        $in  = Player::factory()->create(['position'=>'DEF','price'=>5.0]);

        $this->post('/transfers/swap', ['out_player_id'=>$out->id,'in_player_id'=>$in->id])
             ->assertSessionHasErrors();
    }

    public function test_must_swap_same_position_and_within_budget_and_not_already_owned(): void
    {
        [$gw, $team, $squad] = $this->setupSquad();

        $out = $squad->firstWhere('position','DEF');
        $ownedMid = $squad->firstWhere('position','MID');

        // Wrong position
        $this->post('/transfers/swap', ['out_player_id'=>$out->id,'in_player_id'=>$ownedMid->id])
             ->assertSessionHasErrors();

        // Already own
        $defOwned = $squad->firstWhere('position','DEF');
        $this->post('/transfers/swap', ['out_player_id'=>$out->id,'in_player_id'=>$defOwned->id])
             ->assertSessionHasErrors();

        // Budget exceed
        $expensiveDef = Player::factory()->create(['position'=>'DEF','price'=>14.0]);
        $this->post('/transfers/swap', ['out_player_id'=>$out->id,'in_player_id'=>$expensiveDef->id])
             ->assertSessionHasErrors();
    }
}