<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\Player;
use App\Models\Gameweek;

class TeamSelectionTest extends TestCase
{
    use RefreshDatabase;

    private function seedGameweek(): Gameweek
    {
        return Gameweek::create([
            'name'=>'GW1','number'=>1,'deadline_at'=>now()->addDay(),
        ]);
    }

    public function test_save_selection_enforces_exact_squad_and_positions_and_budget(): void
    {
        $this->seedGameweek();

        // Build exactly 2 GK, 5 DEF, 5 MID, 3 FWD within 100.0 budget
        $players = collect()
            ->merge(Player::factory()->count(2)->create(['position'=>'GK','price'=>4.5]))
            ->merge(Player::factory()->count(5)->create(['position'=>'DEF','price'=>5.0]))
            ->merge(Player::factory()->count(5)->create(['position'=>'MID','price'=>6.0]))
            ->merge(Player::factory()->count(3)->create(['position'=>'FWD','price'=>6.0]));

        $ids = $players->pluck('id')->all();

        $this->post('/team/save', ['player_ids'=>$ids])
             ->assertRedirect('/team')
             ->assertSessionHas('ok');

        // Budget violation example
        $expensive = Player::factory()->count(3)->create(['position'=>'FWD','price'=>14.0]);
        $badIds = collect($ids)->slice(0,12)->merge($expensive->pluck('id'))->all();

        $this->post('/team/save', ['player_ids'=>$badIds])
             ->assertSessionHasErrors();
    }
}