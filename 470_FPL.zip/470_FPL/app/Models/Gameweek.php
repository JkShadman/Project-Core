<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

class Gameweek extends Model
{
    protected $fillable = ['name','number','deadline_at'];
    protected $dates = ['deadline_at'];

    public function isLocked(): bool
    {
        return now()->greaterThanOrEqualTo($this->deadline_at);
    }
}