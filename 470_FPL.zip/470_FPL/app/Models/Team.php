<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Team extends Model
{
    protected $fillable = ['user_id','name','budget','points','transfer_points'];

    public function players()
    {
        return $this->belongsToMany(Player::class, 'team_players')
            ->withPivot('gameweek_id','is_squad')
            ->withTimestamps();
    }

    public function transfers()
    {
        return $this->hasMany(Transfer::class);
    }
}