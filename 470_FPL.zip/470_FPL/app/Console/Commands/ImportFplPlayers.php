<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Arr;
use App\Models\Player;
use Illuminate\Support\Facades\DB;

class ImportFplPlayers extends Command
{
    protected $signature = 'fpl:import-latest {--cache= : Path to write/read bootstrap-static.json cache}';
    protected $description = 'Import latest FPL players from fantasy.premierleague.com bootstrap-static';

    public function handle(): int
    {
        $cachePath = $this->option('cache');

        $json = null;
        if ($cachePath && file_exists($cachePath)) {
            $this->info("Reading cached JSON: $cachePath");
            $json = json_decode(file_get_contents($cachePath), true);
        } else {
            $this->info('Fetching bootstrap-static from FPL...');
            // Endpoint: https://fantasy.premierleague.com/api/bootstrap-static/
            $resp = Http::timeout(20)->get('https://fantasy.premierleague.com/api/bootstrap-static/');
            if (!$resp->ok()) {
                $this->error('Failed to fetch FPL bootstrap-static: HTTP '.$resp->status());
                return self::FAILURE;
            }
            $json = $resp->json();
            if ($cachePath) {
                @file_put_contents($cachePath, json_encode($json, JSON_PRETTY_PRINT));
                $this->info("Cached to: $cachePath");
            }
        }

        $elements      = Arr::get($json, 'elements', []);
        $elementTypes  = collect(Arr::get($json, 'element_types', []))
                            ->keyBy('id')
                            ->map(fn($t) => $t['singular_name_short'] ?? $t['singular_name'] ?? '')
                            ->toArray();
        $teams         = collect(Arr::get($json, 'teams', []))->keyBy('id');

        if (!is_array($elements) || empty($elements)) {
            $this->error('No elements in payload. Aborting.');
            return self::FAILURE;
        }

        // Map FPL types -> our positions
        $map = [
            'GKP' => 'GK',
            'DEF' => 'DEF',
            'MID' => 'MID',
            'FWD' => 'FWD',
            'GK'  => 'GK', // some docs show GK/GKP variations
        ];

        $count = 0;

        DB::transaction(function () use ($elements, $elementTypes, $teams, $map, &$count) {
            // Optionally clear existing to ensure a clean mirror
            Player::query()->delete();

            foreach ($elements as $e) {
                $typeId   = $e['element_type'] ?? null;
                $teamId   = $e['team'] ?? null;

                $typeKey  = $elementTypes[$typeId] ?? null;   // e.g., GKP, DEF, MID, FWD
                $pos      = $map[$typeKey] ?? null;
                if (!$pos) { continue; }

                $clubName = $teams->get($teamId)['name'] ?? 'Unknown';

                Player::create([
                    'name'     => trim(($e['first_name'] ?? '').' '.($e['second_name'] ?? '')),
                    'position' => $pos,
                    'club'     => $clubName,
                    // FPL costs are in tenths of a million, e.g. 125 => 12.5
                    'price'    => isset($e['now_cost']) ? round($e['now_cost'] / 10, 1) : 4.0,
                ]);

                $count++;
            }
        });

        $this->info("Imported players: $count");
        return self::SUCCESS;
    }
}