<?php

namespace App\Http\Controllers;

use App\Models\Player;
use Illuminate\Http\Request;

class PlayerController extends Controller
{
    public function index(Request $request)
    {
        $query = Player::query();

        if ($request->filled('q')) {
            $q = $request->q;
            $query->where(function($sub) use ($q){
                $sub->where('name','like',"%$q%")
                    ->orWhere('club','like',"%$q%")
                    ->orWhere('position','like',"%$q%");
            });
        }
        if ($request->filled('position')) {
            $query->where('position', $request->position);
        }
        if ($request->filled('sort')) {
            $dir = $request->get('dir','asc');
            $query->orderBy($request->sort, $dir);
        } else {
            $query->orderBy('price','desc');
        }

        $players = $query->paginate(12)->withQueryString();
        return view('players.index', compact('players'));
    }
}