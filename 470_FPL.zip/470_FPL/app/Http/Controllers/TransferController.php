<?php

namespace App\Http\Controllers;

use App\Models\Gameweek;
use App\Models\Player;
use App\Models\Team;
use App\Models\TeamPlayer;
use App\Models\Transfer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TransferController extends Controller
{
    private const BUDGET = 100.0;
    private const LIMITS = ['GK'=>2,'DEF'=>5,'MID'=>5,'FWD'=>3];
    private const FREE_TRANSFERS = 1;
    private const EXTRA_COST = 4; // points per extra transfer

    private function currentTeam(): Team
    {
        $userId = session('user_id', 1);
        return Team::firstOrCreate(['user_id'=>$userId], ['budget'=>self::BUDGET]);
    }

    public function index()
    {
        $gw = Gameweek::orderBy('number')->first(); // prototype: always current GW is first
        $team = $this->currentTeam();

        $current = $team->players()->wherePivot('gameweek_id',$gw->id)->get();
        $ownedIds = $current->pluck('id')->toArray();

        $market = Player::orderBy('position')->orderBy('price','desc')->get();

        $made = Transfer::where('team_id',$team->id)->where('gameweek_id',$gw->id)->count();
        $locked = $gw->isLocked();

        return view('transfers.index', compact('gw','team','current','market','ownedIds','made','locked'));
    }

    public function swap(Request $request)
    {
        $gw = Gameweek::orderBy('number')->first();
        if ($gw->isLocked()) {
            return back()->withErrors(['Transfers are locked for '.$gw->name.'.']);
        }

        $team = $this->currentTeam();
        $outId = (int)$request->out_player_id;
        $inId  = (int)$request->in_player_id;

        if ($outId === $inId) {
            return back()->withErrors(['Choose different players for OUT and IN.']);
        }

        $current = $team->players()->wherePivot('gameweek_id',$gw->id)->get();
        if (!$current->pluck('id')->contains($outId)) {
            return back()->withErrors(['Selected OUT player is not in your squad.']);
        }

        $in = Player::findOrFail($inId);
        $out = Player::findOrFail($outId);

        if ($in->position !== $out->position) {
            return back()->withErrors(['Transfers must be same-position swaps in this prototype.']);
        }

        // Budget check
        $spentIfSwap = $current->sum('price') - $out->price + $in->price;
        if ($spentIfSwap > self::BUDGET) {
            return back()->withErrors(['Budget exceeded with this swap.']);
        }

        // Already own incoming?
        if ($current->pluck('id')->contains($inId)) {
            return back()->withErrors(['You already own this player.']);
        }

        // Determine cost
        $made = Transfer::where('team_id',$team->id)->where('gameweek_id',$gw->id)->count();
        $cost = ($made >= self::FREE_TRANSFERS) ? self::EXTRA_COST : 0;

        DB::transaction(function() use ($team, $gw, $outId, $inId, $cost) {
            // Replace in team_players for current GW
            $row = TeamPlayer::where('team_id',$team->id)
                ->where('gameweek_id',$gw->id)
                ->where('player_id',$outId)
                ->firstOrFail();
            $row->player_id = $inId;
            $row->save();

            // Log transfer
            Transfer::create([
                'team_id'=>$team->id,
                'gameweek_id'=>$gw->id,
                'out_player_id'=>$outId,
                'in_player_id'=>$inId,
                'cost'=>$cost,
            ]);

            if ($cost > 0) {
                $team->transfer_points -= $cost; // accumulate negative points
                $team->save();
            }
        });

        return back()->with('ok', 'Transfer completed'.($cost>0?" (-$cost pts penalty)":"").'.');
    }
}