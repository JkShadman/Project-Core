<?php

namespace App\Http\Controllers;

use App\Models\Gameweek;
use App\Models\Player;
use App\Models\Team;
use App\Models\TeamPlayer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TeamController extends Controller
{
    private const BUDGET = 100.0;
    private const SQUAD_SIZE = 15;
    private const LIMITS = ['GK'=>2,'DEF'=>5,'MID'=>5,'FWD'=>3];

    private function currentTeam(): Team
    {
        $userId = session('user_id', 1);
        return Team::firstOrCreate(['user_id' => $userId], ['budget'=>self::BUDGET]);
    }

    public function show()
    {
        $team = $this->currentTeam();
        $gw = Gameweek::orderBy('number')->first();
        $players = $team->players()->wherePivot('gameweek_id', $gw->id)->get();
        $spent = $players->sum('price');
        $remaining = self::BUDGET - $spent;

        $byPos = $players->groupBy('position')->map->count()->toArray();

        return view('team.show', compact('team','players','remaining','byPos','gw'));
    }

    public function selectForm()
    {
        $team = $this->currentTeam();
        $gw = Gameweek::orderBy('number')->first();
        $existing = $team->players()->wherePivot('gameweek_id', $gw->id)->pluck('players.id')->toArray();

        $players = Player::orderBy('position')->orderBy('price','desc')->get();
        return view('team.select', compact('players','existing','gw'));
    }

    public function saveSelection(Request $request)
    {
        $team = $this->currentTeam();
        $gw = Gameweek::orderBy('number')->first();

        $ids = collect($request->get('player_ids', []))->map(fn($v)=>(int)$v)->unique()->values();
        if ($ids->count() !== self::SQUAD_SIZE) {
            return back()->withErrors(['Squad must have exactly '.self::SQUAD_SIZE.' players.'])->withInput();
        }

        $selected = Player::whereIn('id', $ids)->get();
        $spent = $selected->sum('price');
        if ($spent > self::BUDGET) {
            return back()->withErrors(['Budget exceeded. Used '.$spent.' of '.self::BUDGET])->withInput();
        }

        // position limits
        $posCounts = $selected->groupBy('position')->map->count()->toArray();
        foreach (self::LIMITS as $pos => $limit) {
            if (($posCounts[$pos] ?? 0) !== $limit) {
                return back()->withErrors(["Position requirement: $pos must be exactly $limit."])->withInput();
            }
        }

        DB::transaction(function() use ($team, $gw, $ids) {
            TeamPlayer::where('team_id',$team->id)->where('gameweek_id',$gw->id)->delete();
            foreach ($ids as $pid) {
                TeamPlayer::create([
                    'team_id'=>$team->id,
                    'player_id'=>$pid,
                    'gameweek_id'=>$gw->id,
                    'is_squad'=>true,
                ]);
            }
        });

        return redirect()->route('team.show')->with('ok','Squad saved for '.$gw->name.'.');
    }
}