<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('teams', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id'); // single user prototype: always 1
            $table->string('name')->default('My Fantasy XI');
            $table->decimal('budget', 7, 1)->default(100.0);
            $table->integer('points')->default(0);           // cumulative points
            $table->integer('transfer_points')->default(0);  // penalties accumulated
            $table->timestamps();
        });
    }
    public function down(): void {
        Schema::dropIfExists('teams');
    }
};