<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('transfers', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('team_id');
            $table->unsignedBigInteger('gameweek_id');
            $table->unsignedBigInteger('out_player_id');
            $table->unsignedBigInteger('in_player_id');
            $table->integer('cost')->default(0); // points penalty for this transfer
            $table->timestamps();
        });
    }
    public function down(): void {
        Schema::dropIfExists('transfers');
    }
};