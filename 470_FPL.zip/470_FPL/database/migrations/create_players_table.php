<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('players', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->enum('position', ['GK','DEF','MID','FWD']);
            $table->string('club');
            $table->decimal('price', 6, 1); // e.g., 4.5, 12.0
            $table->timestamps();
        });
    }
    public function down(): void {
        Schema::dropIfExists('players');
    }
};