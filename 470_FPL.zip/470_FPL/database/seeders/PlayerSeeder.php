<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Player;

class PlayerSeeder extends Seeder
{
    public function run(): void
    {
        $cache = storage_path('app/bootstrap-static.json');

        if (!file_exists($cache)) {
            // Fallback minimal seed so tests/dev boot even without cached file.
            Player::insert([
                ['name'=>'Erling Haaland','position'=>'FWD','club'=>'Manchester City','price'=>14.0],
                ['name'=>'Mohamed Salah','position'=>'MID','club'=>'Liverpool','price'=>13.0],
                ['name'=>'Alisson Becker','position'=>'GK','club'=>'Liverpool','price'=>6.0],
                ['name'=>'Rúben Dias','position'=>'DEF','club'=>'Manchester City','price'=>6.0],
            ]);
            return;
        }

        $json = json_decode(file_get_contents($cache), true);
        $elements = $json['elements'] ?? [];
        $typesMap = collect($json['element_types'] ?? [])->keyBy('id')
            ->map(fn($t) => $t['singular_name_short'] ?? $t['singular_name'] ?? '')
            ->toArray();
        $teams = collect($json['teams'] ?? [])->keyBy('id');

        $map = ['GKP'=>'GK','DEF'=>'DEF','MID'=>'MID','FWD'=>'FWD','GK'=>'GK'];

        $rows = [];
        foreach ($elements as $e) {
            $typeKey  = $typesMap[$e['element_type']] ?? null;
            $pos      = $map[$typeKey] ?? null;
            if (!$pos) continue;
            $clubName = $teams->get($e['team'])['name'] ?? 'Unknown';

            $rows[] = [
                'name'     => trim(($e['first_name'] ?? '').' '.($e['second_name'] ?? '')),
                'position' => $pos,
                'club'     => $clubName,
                'price'    => isset($e['now_cost']) ? round($e['now_cost']/10, 1) : 4.0,
                'created_at'=> now(),
                'updated_at'=> now(),
            ];
        }

        if ($rows) {
            Player::insert($rows);
        }
    }
}