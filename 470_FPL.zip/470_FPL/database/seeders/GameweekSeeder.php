<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Gameweek;
use Carbon\Carbon;

class GameweekSeeder extends Seeder
{
    public function run(): void
    {
        // Create GW1..GW4 with spaced deadlines
        for ($i=1; $i<=4; $i++) {
            Gameweek::create([
                'name' => 'GW'.$i,
                'number' => $i,
                'deadline_at' => Carbon::now()->addDays($i)->startOfHour(),
            ]);
        }
    }
}