<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class PlayerFactory extends Factory
{
    public function definition(): array
    {
        $pos = $this->faker->randomElement(['GK','DEF','MID','FWD']);
        return [
            'name' => $this->faker->name(),
            'position' => $pos,
            'club' => $this->faker->randomElement(['Arsenal','Chelsea','Liverpool','Manchester City']),
            'price' => $this->faker->randomFloat(1, 4.0, 14.5),
        ];
    }
}